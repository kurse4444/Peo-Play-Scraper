1. Install Requirements

Run the following command to install all dependencies:
pip install -r requirements.txt

2. Activate Virtual Environment

Activate your virtual environment (Windows example):
venv\Scripts\activate

3. Run the Scraper

Once the virtual environment is active, launch the scraper:
python Scraper.py

🇰🇷 한국어 설명 (Korean Explanation)

이 프로그램은 웹 데이터를 자동으로 수집하고, Google Sheets와 같은 외부 서비스에 결과를 저장할 수 있는 
웹 스크래퍼(Web Scraper) 입니다. 사용 방법은 간단합니다. 먼저 requirements.txt 파일의 라이브러리를 설
치하고, 가상 환경(venv)을 활성화한 후 Scraper.py 파일을 실행하면 됩니다. 스크래퍼는 브라우저 자동화 도
구(Selenium)를 사용하여 웹사이트를 탐색하고 필요한 정보를 수집하도록 설계되었습니다.