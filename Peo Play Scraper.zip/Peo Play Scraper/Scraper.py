from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
import gspread
from google.oauth2 import service_account
import json
import time
import os
import traceback
from datetime import datetime

class GooglePAAScraper:
    def __init__(self):
        self.driver = None
        self.all_collected_terms = set()
        
    def setup_driver(self):
        chrome_options = Options()
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--window-size=1200,800")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        
        print("🖥️ Starting browser...")
        
        try:
            # Method 1: Try using local chromedriver.exe first
            if os.path.exists("chromedriver.exe"):
                service = Service("chromedriver.exe")
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
                print("✅ Using local chromedriver.exe")
            else:
                # Method 2: Fallback to automatic
                self.driver = webdriver.Chrome(options=chrome_options)
                print("✅ Using automatic ChromeDriver detection")
                
        except Exception as e:
            print(f"❌ Chrome startup failed: {e}")
            raise
        
        self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        return True
        
    def detect_captcha(self):
        """More accurate CAPTCHA detection with multiple verification methods"""
        captcha_found = False
        
        # Method 1: Check for obvious CAPTCHA elements
        obvious_captcha_indicators = [
            "//iframe[contains(@src, 'recaptcha')]",
            "//div[contains(@class, 'g-recaptcha')]",
            "//div[contains(@class, 'recaptcha')]",
            "//*[contains(text(), 'recaptcha')]",
            "//*[contains(@data-sitekey, '6L')]",
        ]
        
        for indicator in obvious_captcha_indicators:
            try:
                elements = self.driver.find_elements(By.XPATH, indicator)
                if elements:
                    print(f"🔍 Found CAPTCHA element: {indicator}")
                    captcha_found = True
                    break
            except:
                continue
        
        # Method 2: Check for blocked access messages
        if not captcha_found:
            blocking_messages = [
                "//*[contains(text(), 'unusual traffic')]",
                "//*[contains(text(), 'automated requests')]",
                "//*[contains(text(), 'confirm you') and contains(text(), 'robot')]",
                "//*[contains(text(), 'security check')]",
                "//*[contains(text(), 'verify you') and contains(text(), 'human')]",
            ]
            
            for message in blocking_messages:
                try:
                    elements = self.driver.find_elements(By.XPATH, message)
                    if elements:
                        print(f"🔍 Found blocking message: {message}")
                        for element in elements:
                            if element.is_displayed() and element.size['height'] > 20:
                                captcha_found = True
                                break
                except:
                    continue
        
        return captcha_found
    
    def handle_captcha(self):
        """Handle CAPTCHA detection with user confirmation"""
        if self.detect_captcha():
            print("\n" + "="*60)
            print("⚠️  POSSIBLE CAPTCHA DETECTED!")
            print("="*60)
            print("Please check the browser window:")
            print("   • If you see a CAPTCHA, please solve it")
            print("   • If you see search results, just press Enter")
            print("="*60)
            
            try:
                print(f"📄 Current page: {self.driver.title}")
            except:
                pass
            
            response = input("🔄 Press Enter AFTER checking the browser (or type 'skip' to continue): ").strip().lower()
            
            if response == 'skip':
                print("⏩ Skipping CAPTCHA check...")
                return False
            else:
                time.sleep(2)
                if self.detect_captcha():
                    print("❌ CAPTCHA still present.")
                    return True
                else:
                    print("✅ No CAPTCHA found - continuing...")
                    return False
        return False
        
    def search_google(self, query):
        """Perform Google search with better error handling"""
        search_url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        print(f"🔍 Searching: {query}")
        
        try:
            self.driver.get(search_url)
            time.sleep(3)  # Wait for page to load
            
            # Check if we're on a Google search results page
            current_url = self.driver.current_url
            if "google.com/search" not in current_url:
                print(f"⚠️  Not on Google search page. Current URL: {current_url}")
                return False
                
            # Check for CAPTCHA
            self.handle_captcha()
            return True
            
        except Exception as e:
            print(f"❌ Search failed: {e}")
            return False
        
    def get_paa_questions_only(self):
        """Get PAA questions with improved selectors"""
        print("📋 Collecting People Also Ask questions...")
        questions = []
        
        # Updated PAA selectors
        paa_selectors = [
            "div[jsname='N760b']",
            "div[jsname='tJHJj']", 
            "div[data-tts='answers']",
            ".related-question-pair",
            "[jsname='yEVEwb']",
            "[data-ved]"
        ]
        
        # Also try to find by role and common classes
        additional_selectors = [
            "[role='button']",
            ".wQiwMc",
            ".qtjfMc",
            ".CSkcF",
            ".gduDCb"
        ]
        
        all_selectors = paa_selectors + additional_selectors
        
        for selector in all_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    try:
                        text = element.text.strip()
                        if text and len(text) > 10 and '?' in text:
                            # Additional filtering
                            if any(keyword in text.lower() for keyword in ['what', 'how', 'why', 'when', 'where', 'which', 'who', 'can', 'does', 'is', 'are']):
                                if text not in questions:
                                    questions.append(text)
                                    print(f"   ✅ PAA: {text[:80]}...")
                    except:
                        continue
            except Exception as e:
                continue
        
        # Alternative method: Look for question-like text in the page
        if not questions:
            try:
                all_elements = self.driver.find_elements(By.XPATH, "//*[contains(text(), '?')]")
                for element in all_elements:
                    text = element.text.strip()
                    if (text and len(text) > 15 and len(text) < 200 and 
                        text.count('?') == 1 and 
                        any(keyword in text.lower() for keyword in ['what', 'how', 'why', 'when', 'where'])):
                        if text not in questions:
                            questions.append(text)
                            print(f"   ✅ Found question: {text[:80]}...")
            except:
                pass
                
        print(f"📊 Found {len(questions)} PAA questions")
        return questions
    
    def get_people_also_search_for(self):
        """Get People Also Search For with improved detection"""
        print("🔍 Looking for 'People also search for' section...")
        pasf_items = []
        
        # Method 1: Look for the section by text
        section_headers = [
            "People also search for",
            "Related searches", 
            "Searches related to",
            "Others also search for"
        ]
        
        for header in section_headers:
            try:
                # Find the header and then get items near it
                header_elements = self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{header}')]")
                for header_element in header_elements:
                    # Get parent container and find all links/text nearby
                    container = header_element.find_element(By.XPATH, "./ancestor::div[1]")
                    items = container.find_elements(By.TAG_NAME, "a")
                    for item in items:
                        text = item.text.strip()
                        if text and len(text) > 3 and len(text) < 100:
                            if text not in pasf_items and text != header:
                                pasf_items.append(text)
                                print(f"   ✅ PASF: {text}")
            except:
                continue
        
        # Method 2: Look for specific CSS classes and structures
        pasf_selectors = [
            ".exp-outline",
            ".s75CSd", 
            ".OhScic",
            ".A3sX3d",
            ".y6U3qe",
            ".M2vV3v",
            ".eRVBrb",
            "[class*='related']",
            "[class*='also']"
        ]
        
        for selector in pasf_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    text = element.text.strip()
                    if text and len(text) > 3 and len(text) < 100:
                        if text not in pasf_items:
                            pasf_items.append(text)
                            print(f"   ✅ PASF: {text}")
            except:
                continue
        
        # Method 3: Look for cards with multiple items
        try:
            cards = self.driver.find_elements(By.CSS_SELECTOR, ".card, .related-searches, .k8XOCe")
            for card in cards:
                items = card.find_elements(By.TAG_NAME, "a")
                for item in items:
                    text = item.text.strip()
                    if text and len(text) > 3 and len(text) < 100:
                        if text not in pasf_items:
                            pasf_items.append(text)
                            print(f"   ✅ PASF Card: {text}")
        except:
            pass
            
        print(f"📊 Found {len(pasf_items)} 'People also search for' items")
        return pasf_items
    
    def scroll_to_load_more(self):
        """Scroll to trigger loading of more content"""
        print("📜 Scrolling to load more content...")
        
        # Scroll to bottom
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)
        
        # Scroll up a bit
        self.driver.execute_script("window.scrollTo(0, 500);")
        time.sleep(1)
        
        # Scroll down again
        self.driver.execute_script("window.scrollTo(0, 800);")
        time.sleep(2)

    def apply_filter_conditions(self, search_terms):
        """Apply filtering conditions to search terms - LESS RESTRICTIVE"""
        filtered_terms = []
        
        for term in search_terms:
            term_lower = term.lower()
            
            # LESS restrictive filtering - only exclude obvious non-search terms
            if (len(term) >= 3 and  # Shorter minimum length
                not any(exclude in term_lower for exclude in [
                    'images', 'videos', 'news', 'shopping', 'maps', 'books', 'flights', 
                    'hotels', 'translate', 'finance', 'scholar'
                ]) and
                'people also' not in term_lower and
                'related searches' not in term_lower):
                filtered_terms.append(term)
        
        print(f"🔍 Filtered {len(search_terms)} terms down to {len(filtered_terms)}")
        return filtered_terms

    def iterative_search(self, initial_query, max_iterations=3, max_terms_per_iteration=5):
        """Perform iterative search with better error handling"""
        print(f"\n🔄 Starting iterative search with: '{initial_query}'")
        print(f"📈 Maximum iterations: {max_iterations}")
        
        all_paa_questions = []
        all_pasf_items = []
        searched_terms = set()
        terms_to_search = [initial_query]
        
        # Store data for each individual search term
        term_specific_data = {}
        
        iteration = 1
        
        # Setup driver once for the entire iterative search
        self.setup_driver()
        
        try:
            while terms_to_search and iteration <= max_iterations:
                print(f"\n{'='*60}")
                print(f"🔄 ITERATION {iteration}")
                print(f"{'='*60}")
                
                current_batch = terms_to_search[:max_terms_per_iteration]
                terms_to_search = terms_to_search[max_terms_per_iteration:]
                
                new_terms_found = []
                
                for search_term in current_batch:
                    if search_term in searched_terms:
                        continue
                        
                    print(f"\n🎯 Searching: '{search_term}'")
                    searched_terms.add(search_term)
                    
                    # Perform search
                    search_success = self.search_google(search_term)
                    if not search_success:
                        print(f"❌ Search failed for '{search_term}', skipping...")
                        continue
                    
                    # Scroll to load more content
                    self.scroll_to_load_more()
                    
                    # Get PAA questions for THIS specific search term
                    paa_questions = self.get_paa_questions_only()
                    
                    # Get People Also Search For for THIS specific search term
                    pasf_items = self.get_people_also_search_for()
                    
                    # Store the data for this specific term
                    term_specific_data[search_term] = {
                        'people_also_ask': paa_questions,
                        'people_also_search_for': pasf_items
                    }
                    
                    # Add to overall collections
                    for question in paa_questions:
                        if question not in all_paa_questions:
                            all_paa_questions.append(question)
                    
                    for item in pasf_items:
                        if item not in all_pasf_items:
                            all_pasf_items.append(item)
                    
                    # Apply filtering to new terms (LESS restrictive)
                    filtered_new_terms = self.apply_filter_conditions(pasf_items)
                    
                    # Add filtered terms to next search batch
                    for term in filtered_new_terms:
                        if (term not in searched_terms and 
                            term not in terms_to_search and 
                            term not in new_terms_found):
                            new_terms_found.append(term)
                            print(f"   ➕ New term for next iteration: {term}")
                    
                    print(f"✅ Found {len(paa_questions)} PAA questions, {len(pasf_items)} PASF items")
                    print(f"📈 New filtered terms for next iteration: {len(new_terms_found)}")
                    
                    # Small delay between searches
                    time.sleep(3)
                
                # Add new terms to search queue
                terms_to_search.extend(new_terms_found)
                
                print(f"\n📊 Iteration {iteration} Summary:")
                print(f"   • Searched terms: {len(searched_terms)}")
                print(f"   • Total PAA questions: {len(all_paa_questions)}")
                print(f"   • Total PASF items: {len(all_pasf_items)}")
                print(f"   • Terms for next iteration: {len(terms_to_search)}")
                
                iteration += 1
                
                # Stop if no new terms found
                if not terms_to_search:
                    print("🛑 No new terms found - stopping iterations")
                    break
            
            # Prepare final results
            results = {
                'search_query': initial_query,
                'timestamp': datetime.now().isoformat(),
                'people_also_ask': all_paa_questions,
                'people_also_search_for': all_pasf_items,
                'iterative_search_summary': {
                    'iterations_completed': iteration - 1,
                    'total_terms_searched': len(searched_terms),
                    'total_paa_questions': len(all_paa_questions),
                    'total_pasf_items': len(all_pasf_items),
                    'searched_terms': list(searched_terms)
                },
                'term_specific_data': term_specific_data  # NEW: Store data for each term
            }
            
            print(f"\n🎉 ITERATIVE SEARCH COMPLETE!")
            print(f"📈 Final Results:")
            print(f"   • Iterations: {iteration - 1}")
            print(f"   • Total terms searched: {len(searched_terms)}")
            print(f"   • Total PAA questions: {len(all_paa_questions)}")
            print(f"   • Total PASF items: {len(all_pasf_items)}")
            
            return results
            
        except Exception as e:
            print(f"❌ Iterative search failed: {e}")
            return None
        finally:
            if self.driver:
                self.driver.quit()

    def single_search(self, query, min_paa_questions=5):
        """Single search with improved detection"""
        print(f"\n🚀 Starting single search for: '{query}'")
        
        try:
            self.setup_driver()
            search_success = self.search_google(query)
            
            if not search_success:
                print("❌ Search failed")
                return None
            
            # Scroll to load more content
            self.scroll_to_load_more()
            
            # Get PAA questions
            paa_questions = self.get_paa_questions_only()
            
            # Get People Also Search For
            pasf_items = self.get_people_also_search_for()
            
            # Prepare results
            results = {
                'search_query': query,
                'timestamp': datetime.now().isoformat(),
                'people_also_ask': paa_questions,
                'people_also_search_for': pasf_items,
                'summary': {
                    'paa_count': len(paa_questions),
                    'pasf_count': len(pasf_items),
                    'total_items': len(paa_questions) + len(pasf_items)
                }
            }
            
            print(f"\n📊 SCRAPING SUMMARY:")
            print(f"   • People Also Ask: {len(paa_questions)} questions")
            print(f"   • People Also Search For: {len(pasf_items)} items")
            print(f"   • Total collected: {len(paa_questions) + len(pasf_items)} items")
            
            return results
            
        except Exception as e:
            print(f"❌ Scraping failed: {e}")
            return None
        finally:
            if self.driver:
                self.driver.quit()

    def scrape_all_data(self, query, min_paa_questions=5, enable_iterative_search=False, max_iterations=3):
        """Main scraping function"""
        if enable_iterative_search:
            return self.iterative_search(query, max_iterations)
        else:
            return self.single_search(query, min_paa_questions)

class GoogleSheetsManager:
    def __init__(self):
        self.worksheet = None
        self.client = None
        self.last_write_time = 0
        self.write_delay = 3  # Increased delay to avoid quota issues
    
    def test_sheets_connection(self):
        """Test if we can actually write to Google Sheets"""
        try:
            test_row = ['TEST', 'Connection Test', 'Result1', 'Result2', '', '', '', '', '', '', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'Test']
            success = self.safe_append_row(test_row)
            if success:
                print("✅ Google Sheets connection test: SUCCESS")
                return True
            else:
                print("❌ Google Sheets connection test: FAILED")
                return False
        except Exception as e:
            print(f"❌ Google Sheets connection test error: {e}")
            return False
        
    def setup_sheets(self):
        """Setup Google Sheets with proper authentication - USE EXISTING SHEET ONLY"""
        if not os.path.exists('credentials.json'):
            print("❌ credentials.json not found - Google Sheets disabled")
            return False
            
        try:
            # Use alternative authentication that works
            SCOPES = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
            
            creds = service_account.Credentials.from_service_account_file(
                'credentials.json', 
                scopes=SCOPES
            )
            
            self.client = gspread.authorize(creds)
            
            # Use your specific Google Sheet name
            sheet_name = "Keyword & Question Collection"
            
            # ONLY use existing sheet - do not create new one
            try:
                sheet = self.client.open(sheet_name)
                print(f"✅ Connected to existing Google Sheet: '{sheet_name}'")
            except gspread.SpreadsheetNotFound:
                print(f"❌ Google Sheet '{sheet_name}' not found!")
                print("💡 Please create the Google Sheet manually and share it with your service account email")
                return False
            
            self.worksheet = sheet.sheet1
            
            # Test the connection
            print("🔍 Testing Google Sheets connection...")
            if not self.test_sheets_connection():
                print("❌ Google Sheets connection test failed - check permissions and credentials")
                return False
            
            # Check if sheet has data and setup headers only if completely empty
            try:
                # Get all values to check if sheet is empty
                all_values = self.worksheet.get_all_values()
                if not all_values:
                    # Sheet is completely empty, add new format headers
                    headers = [
                        'Start Question', 
                        'Filtered Keyword',
                        'Result1', 'Result2', 'Result3', 'Result4',
                        'Result5', 'Result6', 'Result7', 'Result8',
                        'Timestamp',
                        'Search Type'
                    ]
                    self.worksheet.append_row(headers)
                    print("✅ Added new format headers to empty sheet")
                else:
                    print(f"✅ Sheet already has {len(all_values)} rows of data - PRESERVING ALL EXISTING DATA")
                    print("💡 New searches will be appended to the existing data")
            except Exception as e:
                print(f"⚠️  Could not check sheet data: {e}")
                # If we can't check, assume it has data and don't clear
            
            print(f"📊 Sheet URL: https://docs.google.com/spreadsheets/d/{sheet.id}")
            return True
            
        except Exception as e:
            print(f"❌ Google Sheets setup failed: {e}")
            return False
    
    def rate_limit_write(self):
        """Implement rate limiting to avoid quota issues"""
        current_time = time.time()
        time_since_last_write = current_time - self.last_write_time
        
        if time_since_last_write < self.write_delay:
            sleep_time = self.write_delay - time_since_last_write
            print(f"⏳ Rate limiting: waiting {sleep_time:.1f}s before next write...")
            time.sleep(sleep_time)
        
        self.last_write_time = time.time()
    
    def safe_append_row(self, row_data):
        """Safely append a row with rate limiting and error handling"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                self.rate_limit_write()
                self.worksheet.append_row(row_data)
                return True
            except gspread.exceptions.APIError as e:
                if "429" in str(e) or "Quota exceeded" in str(e):
                    wait_time = 60 * (attempt + 1)  # 60, 120, 180 seconds
                    print(f"⚠️  Google Sheets quota exceeded. Waiting {wait_time} seconds (attempt {attempt + 1}/{max_retries})...")
                    time.sleep(wait_time)
                    continue
                else:
                    print(f"❌ Google Sheets API error: {e}")
                    return False
            except Exception as e:
                print(f"❌ Failed to write to Google Sheets (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(10)
                    continue
                else:
                    return False
        return False
    
    def format_search_row(self, search_term, term_data):
        """Format a single search row with ACTUAL data for that specific term"""
        # Use the actual data collected for this specific search term
        paa_questions = term_data.get('people_also_ask', [])
        pasf_items = term_data.get('people_also_search_for', [])
        
        print(f"   🔍 Formatting row for '{search_term}': {len(paa_questions)} PAA, {len(pasf_items)} PASF")
        
        # Show actual data being used
        if paa_questions:
            print(f"   ❓ Actual PAA for '{search_term}': {paa_questions[0][:60]}...")
        if pasf_items:
            print(f"   🔍 Actual PASF for '{search_term}': {pasf_items[0][:60]}...")
        
        # Combine PAA questions and PASF items for THIS specific term
        all_results = paa_questions[:4] + pasf_items[:4]
        all_results = all_results[:8]  # Ensure max 8 results
        
        # Create the row data
        row_data = [
            '',  # Start Question (empty for now)
            search_term,  # Filtered Keyword
        ]
        
        # Add results (up to 8) - these are the ACTUAL results for this term
        for i in range(8):
            if i < len(all_results):
                row_data.append(all_results[i])
            else:
                row_data.append('')  # Empty cell if no result
        
        # Add timestamp and search type
        row_data.append(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        row_data.append('Iterative')
        
        return row_data
    
    def add_spacing(self):
        """Add empty rows for spacing between searches"""
        try:
            # Add 2 empty rows for spacing with correct number of columns
            empty_row = [''] * 12  # 12 columns in new format
            self.safe_append_row(empty_row)
            self.safe_append_row(empty_row)
            print("📝 Added spacing between searches")
        except Exception as e:
            print(f"⚠️  Could not add spacing: {e}")
    
    def add_data(self, query, data, search_type="Single"):
        """Add data to Google Sheets in the new format - PRESERVE EXISTING DATA"""
        if not self.worksheet:
            print("📝 Google Sheets not available - saving locally only")
            return False
            
        try:
            print(f"📤 Adding data to Google Sheets in new format...")
            print(f"🔍 Search type: {search_type}")
            
            rows_added = 0
            
            # Add spacing from previous data
            self.add_spacing()
            
            # Add separator row to identify new search session
            separator_row = [''] * 12
            separator_row[0] = f"🚀 NEW SEARCH SESSION"
            separator_row[1] = f"Original Query: {query}"
            separator_row[10] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            separator_row[11] = search_type
            
            if self.safe_append_row(separator_row):
                rows_added += 1
                print(f"   📍 Added separator for new search session")
            else:
                print("❌ Failed to add separator row")
                return False
            
            # For iterative search, create a row for each searched term WITH ITS OWN DATA
            if search_type == "Iterative" and 'term_specific_data' in data:
                term_specific_data = data['term_specific_data']
                searched_terms = data['iterative_search_summary']['searched_terms']
                print(f"📝 Creating {len(searched_terms)} rows for iterative search...")
                
                for i, search_term in enumerate(searched_terms):
                    # Get the ACTUAL data collected for this specific term
                    if search_term in term_specific_data:
                        term_data = term_specific_data[search_term]
                        row_data = self.format_search_row(search_term, term_data)
                        print(f"   🔍 Row {i+1} for '{search_term}': {len(term_data.get('people_also_ask', []))} PAA, {len(term_data.get('people_also_search_for', []))} PASF")
                        
                        if self.safe_append_row(row_data):
                            rows_added += 1
                            print(f"   ✅ Added row {i+1}/{len(searched_terms)} for: {search_term}")
                        else:
                            print(f"❌ Failed to add row for: {search_term}")
                    else:
                        print(f"⚠️  No data found for term: {search_term}")
            else:
                # For single search, create one main row
                row_data = self.format_search_row(query, data)
                print(f"   🔍 Main row for '{query}': {len(data.get('people_also_ask', []))} PAA, {len(data.get('people_also_search_for', []))} PASF")
                
                if self.safe_append_row(row_data):
                    rows_added += 1
                    print(f"   ✅ Added main row for: {query}")
                else:
                    print(f"❌ Failed to add main row for: {query}")
                    return False
            
            # Add a summary row
            total_items = len(data.get('people_also_ask', [])) + len(data.get('people_also_search_for', []))
            summary_row = [
                'SUMMARY',
                f"Total: {total_items} items (PAA: {len(data.get('people_also_ask', []))}, PASF: {len(data.get('people_also_search_for', []))})",
                '', '', '', '', '', '', '', '',  # Empty result columns
                datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                search_type
            ]
            
            if self.safe_append_row(summary_row):
                rows_added += 1
                print("   📊 Added summary row")
            
            if rows_added > 0:
                print(f"🎉 Successfully added {rows_added} rows to Google Sheets!")
                print("📊 New format: Start Question | Filtered Keyword | Results 1-8 | Timestamp | Search Type")
                print("💾 All existing data preserved!")
                return True
            else:
                print("❌ No rows were added to Google Sheets")
                return False
            
        except Exception as e:
            print(f"❌ Failed to add data to Google Sheets: {e}")
            print(f"🔍 Full error: {traceback.format_exc()}")
            return False

def print_results(data):
    """Print the collected data in a formatted way"""
    if not data:
        print("❌ No data collected")
        return
        
    print(f"\n🎉 COLLECTED DATA FOR: '{data['search_query']}'")
    print("=" * 80)
    
    # Print People Also Ask
    if data['people_also_ask']:
        print(f"\n📋 PEOPLE ALSO ASK ({len(data['people_also_ask'])} questions):")
        print("-" * 40)
        for i, question in enumerate(data['people_also_ask'][:10], 1):
            print(f"{i}. {question}")
        if len(data['people_also_ask']) > 10:
            print(f"... and {len(data['people_also_ask']) - 10} more questions")
    else:
        print(f"\n❌ No People Also Ask questions found")
    
    # Print People Also Search For
    if data['people_also_search_for']:
        print(f"\n🔍 PEOPLE ALSO Search FOR ({len(data['people_also_search_for'])} items):")
        print("-" * 40)
        for i, item in enumerate(data['people_also_search_for'][:10], 1):
            print(f"{i}. {item}")
        if len(data['people_also_search_for']) > 10:
            print(f"... and {len(data['people_also_search_for']) - 10} more items")
    else:
        print(f"\n❌ No People Also Search For items found")
    
    # Print iterative search summary if available
    if 'iterative_search_summary' in data:
        summary = data['iterative_search_summary']
        print(f"\n📈 ITERATIVE SEARCH SUMMARY:")
        print("-" * 40)
        print(f"   • Iterations completed: {summary['iterations_completed']}")
        print(f"   • Total terms searched: {summary['total_terms_searched']}")
        print(f"   • Total PAA questions: {summary['total_paa_questions']}")
        print(f"   • Total PASF items: {summary['total_pasf_items']}")
        if summary['searched_terms']:
            print(f"   • Searched terms: {', '.join(summary['searched_terms'][:5])}{'...' if len(summary['searched_terms']) > 5 else ''}")
    
    print(f"\n📊 SUMMARY: {len(data['people_also_ask']) + len(data['people_also_search_for'])} total items collected")

def main():
    print("🔎 GOOGLE SCRAPER - PAA & PEOPLE ALSO SEARCH FOR")
    print("=" * 60)
    print("✨ FIXED VERSION - Now shows ACTUAL scraped data for each term")
    print("=" * 60)
    
    # Setup Google Sheets
    sheets_manager = GoogleSheetsManager()
    sheets_ready = sheets_manager.setup_sheets()
    
    if sheets_ready:
        print("\n✅ Google Sheets integration ready!")
        print("💡 Using new spreadsheet format")
        print("⏰ Rate limiting enabled to avoid quota issues")
        print("📊 Format: Start Question | Filtered Keyword | Results 1-8 | Timestamp | Search Type")
        print("💾 ALL EXISTING DATA WILL BE PRESERVED!")
    else:
        print("\n💡 Google Sheets not available - saving locally only")
    
    while True:
        # Get search query
        query = input("\n📝 무엇을 검색하시겠습니까? : What would you like to search for? :  ").strip()
        if not query:
            continue
        
        # Ask for search type
        print("\n🔍 Choose search type:")
        print("   1. Single search (fast)")
        print("   2. Iterative search (comprehensive)")
        search_choice = input("   Enter choice (1 or 2): ").strip()
        
        enable_iterative = search_choice == "2"
        max_iterations = 3
        
        if enable_iterative:
            try:
                iterations_input = input("   Enter number of iterations (default 3): ").strip()
                if iterations_input:
                    max_iterations = int(iterations_input)
            except ValueError:
                print("   ⚠️  Using default 3 iterations")
        
        # Scrape data
        scraper = GooglePAAScraper()
        results = scraper.scrape_all_data(
            query, 
            enable_iterative_search=enable_iterative,
            max_iterations=max_iterations
        )
        
        # Display results
        if results:
            print_results(results)
            
            # Save locally
            search_type = "iterative" if enable_iterative else "single"
            filename = f"google_data_{query.replace(' ', '_')}_{search_type}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            print(f"\n💾 Saved locally as: {filename}")
            
            # Save to Google Sheets (with error handling)
            if sheets_ready:
                print("\n" + "="*50)
                search_type_label = "Iterative" if enable_iterative else "Single"
                success = sheets_manager.add_data(query, results, search_type_label)
                if success:
                   print("🎊 데이터가 구글 시트에 성공적으로 추가되었습니다! / DATA SUCCESSFULLY ADDED TO GOOGLE SHEETS!")
                   print("📊 새로운 형식으로 데이터가 저장되었습니다! / Data saved in new format!")
                   print("💾 모든 기존 데이터가 보존되었습니다! / All existing data preserved!")
                else:
                    print("❌ 구글 시트 저장 실패 / Failed to save to Google Sheets")
                    print("💡 Data was saved locally. Try again later when quota resets.")
        
        # Continue?
        cont = input("\n🔄 다시 검색하시겠습니까? (y/n): / Search again? (y/n): ").strip().lower()
        if cont not in ['y', 'yes']:
            print("👋 안녕히 가세요! / Goodbye!")
            break

if __name__ == "__main__":
    main()  