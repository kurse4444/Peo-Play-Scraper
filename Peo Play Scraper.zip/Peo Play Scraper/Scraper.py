from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
import gspread
from google.oauth2 import service_account
import json
import time
import os
import traceback
from datetime import datetime

class GooglePAAScraper:
    def __init__(self):
        self.driver = None
        self.all_collected_terms = set()
        
    def setup_driver(self):
        chrome_options = Options()
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--window-size=1200,800")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        
        print("🖥️ Starting browser...")
        
        try:
            if os.path.exists("chromedriver.exe"):
                service = Service("chromedriver.exe")
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
                print("✅ Using local chromedriver.exe")
            else:
                self.driver = webdriver.Chrome(options=chrome_options)
                print("✅ Using automatic ChromeDriver detection")
                
        except Exception as e:
            print(f"❌ Chrome startup failed: {e}")
            raise
        
        self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        return True
        
    def detect_captcha(self):
        captcha_found = False
        
        obvious_captcha_indicators = [
            "//iframe[contains(@src, 'recaptcha')]",
            "//div[contains(@class, 'g-recaptcha')]",
            "//div[contains(@class, 'recaptcha')]",
            "//*[contains(text(), 'recaptcha')]",
            "//*[contains(@data-sitekey, '6L')]",
        ]
        
        for indicator in obvious_captcha_indicators:
            try:
                elements = self.driver.find_elements(By.XPATH, indicator)
                if elements:
                    captcha_found = True
                    break
            except:
                continue
        
        if not captcha_found:
            blocking_messages = [
                "//*[contains(text(), 'unusual traffic')]",
                "//*[contains(text(), 'automated requests')]",
                "//*[contains(text(), 'confirm you') and contains(text(), 'robot')]",
                "//*[contains(text(), 'security check')]",
                "//*[contains(text(), 'verify you') and contains(text(), 'human')]",
            ]
            
            for message in blocking_messages:
                try:
                    elements = self.driver.find_elements(By.XPATH, message)
                    if elements:
                        for element in elements:
                            if element.is_displayed() and element.size['height'] > 20:
                                captcha_found = True
                                break
                except:
                    continue
        
        return captcha_found
    
    def handle_captcha(self):
        if self.detect_captcha():
            print("\n" + "="*60)
            print("⚠️  POSSIBLE CAPTCHA DETECTED!")
            print("="*60)
            print("Please check the browser window:")
            print("   • If you see a CAPTCHA, please solve it")
            print("   • If you see search results, just press Enter")
            print("="*60)
            
            try:
                print(f"📄 Current page: {self.driver.title}")
            except:
                pass
            
            response = input("🔄 Press Enter AFTER checking the browser (or type 'skip' to continue): ").strip().lower()
            
            if response == 'skip':
                return False
            else:
                time.sleep(2)
                if self.detect_captcha():
                    return True
                else:
                    return False
        return False
        
    def search_google(self, query):
        search_url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        print(f"🔍 Searching: {query}")
        
        try:
            self.driver.get(search_url)
            time.sleep(3)
            
            current_url = self.driver.current_url
            if "google.com/search" not in current_url:
                return False
                
            self.handle_captcha()
            return True
            
        except Exception as e:
            print(f"❌ Search failed: {e}")
            return False
        
    def get_paa_questions_only(self):
        """Get ONLY the PAA questions without answers"""
        print("📋 Collecting People Also Ask questions (questions only)...")
        questions = []
        
        paa_selectors = [
            "div[jsname='N760b']",
            "div[jsname='tJHJj']", 
            "div[data-tts='answers']",
            ".related-question-pair",
            "[jsname='yEVEwb']",
            "[data-ved]"
        ]
        
        additional_selectors = [
            "[role='button']",
            ".wQiwMc",
            ".qtjfMc",
            ".CSkcF",
            ".gduDCb"
        ]
        
        all_selectors = paa_selectors + additional_selectors
        
        for selector in all_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    try:
                        text = element.text.strip()
                        # Only Questions
                        if text and '?' in text:
                            
                            question_only = self.extract_question_only(text)
                            if question_only and len(question_only) > 10:
                                if question_only not in questions:
                                    questions.append(question_only)
                                    print(f"   ✅ PAA Question: {question_only[:80]}...")
                    except:
                        continue
            except:
                continue
        
        # Alternative method for finding questions
        if not questions:
            try:
                all_elements = self.driver.find_elements(By.XPATH, "//*[contains(text(), '?')]")
                for element in all_elements:
                    text = element.text.strip()
                    if (text and len(text) > 15 and len(text) < 200 and 
                        text.count('?') == 1):
                        question_only = self.extract_question_only(text)
                        if question_only and question_only not in questions:
                            questions.append(question_only)
            except:
                pass
                
        print(f"📊 Found {len(questions)} PAA questions (questions only)")
        return questions
    #Question Identifier Logic
    def extract_question_only(self, text):
        """Extract only the question part, removing any answers or extra text"""
        
        separators = ['\n', '•', '-', '–', '—', '|', ':']
        
        for separator in separators:
            if separator in text:
                parts = text.split(separator)
                
                for part in parts:
                    if '?' in part:
                        question = part.strip()
                        
                        question = question.replace('  ', ' ')
                        if question.endswith('?'):
                            return question
                        else:
                            
                            q_index = question.find('?')
                            if q_index != -1:
                                return question[:q_index + 1].strip()
        
        
        if '?' in text:
            q_index = text.find('?')
            return text[:q_index + 1].strip()
        
        return text
    
    def get_people_also_search_for(self):
        print("🔍 Looking for 'People also search for' section...")
        pasf_items = []
        
        section_headers = [
            "People also search for",
            "Related searches", 
            "Searches related to",
            "Others also search for"
        ]
        
        for header in section_headers:
            try:
                header_elements = self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{header}')]")
                for header_element in header_elements:
                    container = header_element.find_element(By.XPATH, "./ancestor::div[1]")
                    items = container.find_elements(By.TAG_NAME, "a")
                    for item in items:
                        text = item.text.strip()
                        if text and len(text) > 3 and len(text) < 100:
                            if text not in pasf_items and text != header:
                                pasf_items.append(text)
            except:
                continue
        
        pasf_selectors = [
            ".exp-outline",
            ".s75CSd", 
            ".OhScic",
            ".A3sX3d",
            ".y6U3qe",
            ".M2vV3v",
            ".eRVBrb",
            "[class*='related']",
            "[class*='also']"
        ]
        
        for selector in pasf_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    text = element.text.strip()
                    if text and len(text) > 3 and len(text) < 100:
                        if text not in pasf_items:
                            pasf_items.append(text)
            except:
                continue
        
        try:
            cards = self.driver.find_elements(By.CSS_SELECTOR, ".card, .related-searches, .k8XOCe")
            for card in cards:
                items = card.find_elements(By.TAG_NAME, "a")
                for item in items:
                    text = item.text.strip()
                    if text and len(text) > 3 and len(text) < 100:
                        if text not in pasf_items:
                            pasf_items.append(text)
        except:
            pass
            
        print(f"📊 Found {len(pasf_items)} 'People also search for' items")
        return pasf_items
    
    def scroll_to_load_more(self):
        print("📜 Scrolling to load more content...")
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)
        self.driver.execute_script("window.scrollTo(0, 500);")
        time.sleep(1)
        self.driver.execute_script("window.scrollTo(0, 800);")
        time.sleep(2)

    def apply_filter_conditions(self, search_terms):
        filtered_terms = []
        
        for term in search_terms:
            term_lower = term.lower()
            if (len(term) >= 3 and
                not any(exclude in term_lower for exclude in [
                    'images', 'videos', 'news', 'shopping', 'maps', 'books', 'flights', 
                    'hotels', 'translate', 'finance', 'scholar'
                ]) and
                'people also' not in term_lower and
                'related searches' not in term_lower):
                filtered_terms.append(term)
        
        print(f"🔍 Filtered {len(search_terms)} terms down to {len(filtered_terms)}")
        return filtered_terms

    def iterative_search(self, initial_query, max_iterations=3, max_terms_per_iteration=5):
        print(f"\n🔄 Starting iterative search with: '{initial_query}'")
        print(f"📈 Maximum iterations: {max_iterations}")
        
        all_paa_questions = []
        all_pasf_items = []
        searched_terms = set()
        terms_to_search = [initial_query]
        term_specific_data = {}
        iteration = 1
        
        self.setup_driver()
        
        try:
            while terms_to_search and iteration <= max_iterations:
                print(f"\n{'='*60}")
                print(f"🔄 ITERATION {iteration}")
                print(f"{'='*60}")
                
                current_batch = terms_to_search[:max_terms_per_iteration]
                terms_to_search = terms_to_search[max_terms_per_iteration:]
                new_terms_found = []
                
                for search_term in current_batch:
                    if search_term in searched_terms:
                        continue
                        
                    print(f"\n🎯 Searching: '{search_term}'")
                    searched_terms.add(search_term)
                    
                    search_success = self.search_google(search_term)
                    if not search_success:
                        continue
                    
                    self.scroll_to_load_more()
                    paa_questions = self.get_paa_questions_only()  
                    pasf_items = self.get_people_also_search_for()
                    
                    term_specific_data[search_term] = {
                        'people_also_ask': paa_questions,
                        'people_also_search_for': pasf_items
                    }
                    
                    for question in paa_questions:
                        if question not in all_paa_questions:
                            all_paa_questions.append(question)
                    
                    for item in pasf_items:
                        if item not in all_pasf_items:
                            all_pasf_items.append(item)
                    
                    filtered_new_terms = self.apply_filter_conditions(pasf_items)
                    
                    for term in filtered_new_terms:
                        if (term not in searched_terms and 
                            term not in terms_to_search and 
                            term not in new_terms_found):
                            new_terms_found.append(term)
                    
                    print(f"✅ Found {len(paa_questions)} PAA questions, {len(pasf_items)} PASF items")
                    time.sleep(3)
                
                terms_to_search.extend(new_terms_found)
                iteration += 1
                
                if not terms_to_search:
                    break
            
            results = {
                'search_query': initial_query,
                'timestamp': datetime.now().isoformat(),
                'people_also_ask': all_paa_questions,
                'people_also_search_for': all_pasf_items,
                'iterative_search_summary': {
                    'iterations_completed': iteration - 1,
                    'total_terms_searched': len(searched_terms),
                    'total_paa_questions': len(all_paa_questions),
                    'total_pasf_items': len(all_pasf_items),
                    'searched_terms': list(searched_terms)
                },
                'term_specific_data': term_specific_data
            }
            
            print(f"\n🎉 ITERATIVE SEARCH COMPLETE!")
            return results
            
        except Exception as e:
            print(f"❌ Iterative search failed: {e}")
            return None
        finally:
            if self.driver:
                self.driver.quit()

    def single_search(self, query, min_paa_questions=5):
        print(f"\n🚀 Starting single search for: '{query}'")
        
        try:
            self.setup_driver()
            search_success = self.search_google(query)
            
            if not search_success:
                return None
            
            self.scroll_to_load_more()
            paa_questions = self.get_paa_questions_only()  
            pasf_items = self.get_people_also_search_for()
            
            results = {
                'search_query': query,
                'timestamp': datetime.now().isoformat(),
                'people_also_ask': paa_questions,
                'people_also_search_for': pasf_items,
                'summary': {
                    'paa_count': len(paa_questions),
                    'pasf_count': len(pasf_items),
                    'total_items': len(paa_questions) + len(pasf_items)
                }
            }
            
            return results
            
        except Exception as e:
            print(f"❌ Scraping failed: {e}")
            return None
        finally:
            if self.driver:
                self.driver.quit()

    def scrape_all_data(self, query, min_paa_questions=5, enable_iterative_search=False, max_iterations=3):
        if enable_iterative_search:
            return self.iterative_search(query, max_iterations)
        else:
            return self.single_search(query, min_paa_questions)

class GoogleSheetsManager:
    def __init__(self):
        self.worksheet = None
        self.client = None
        self.spreadsheet = None
        self.last_write_time = 0
        self.write_delay = 3
    
    def create_new_tab(self, query, search_type):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_query = "".join(c for c in query[:20] if c.isalnum() or c in (' ', '-', '_')).rstrip()
        tab_name = f"{safe_query}_{search_type}_{timestamp}"
        
        try:
            new_worksheet = self.spreadsheet.add_worksheet(title=tab_name, rows=1000, cols=20)
            self.worksheet = new_worksheet
            print(f"📑 Created new tab: '{tab_name}'")
            return True
        except Exception as e:
            print(f"❌ Failed to create new tab: {e}")
            self.worksheet = self.spreadsheet.sheet1
            return False
    
    def setup_sheets(self):
        if not os.path.exists('credentials.json'):
            print("❌ credentials.json not found - Google Sheets disabled")
            return False
            
        try:
            SCOPES = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
            creds = service_account.Credentials.from_service_account_file('credentials.json', scopes=SCOPES)
            self.client = gspread.authorize(creds)
            
            sheet_name = "Keyword & Question Collection"
            try:
                self.spreadsheet = self.client.open(sheet_name)
                print(f"✅ Connected to existing Google Sheet: '{sheet_name}'")
            except gspread.SpreadsheetNotFound:
                print(f"❌ Google Sheet '{sheet_name}' not found!")
                return False
            
            self.worksheet = self.spreadsheet.sheet1
            print(f"📊 Sheet URL: https://docs.google.com/spreadsheets/d/{self.spreadsheet.id}")
            return True
            
        except Exception as e:
            print(f"❌ Google Sheets setup failed: {e}")
            return False
    
    def rate_limit_write(self):
        current_time = time.time()
        time_since_last_write = current_time - self.last_write_time
        if time_since_last_write < self.write_delay:
            sleep_time = self.write_delay - time_since_last_write
            time.sleep(sleep_time)
        self.last_write_time = time.time()
    
    def safe_append_row(self, row_data):
        max_retries = 3
        for attempt in range(max_retries):
            try:
                self.rate_limit_write()
                self.worksheet.append_row(row_data)
                return True
            except gspread.exceptions.APIError as e:
                if "429" in str(e) or "Quota exceeded" in str(e):
                    wait_time = 60 * (attempt + 1)
                    time.sleep(wait_time)
                    continue
                else:
                    return False
            except Exception as e:
                if attempt < max_retries - 1:
                    time.sleep(10)
                    continue
                else:
                    return False
        return False

    def apply_formatting(self, total_rows):
        """Apply formatting with questions only and top-aligned text"""
        try:
            print("🎨 Applying formatting to the sheet...")
            
            spreadsheet_id = self.spreadsheet.id
            sheet_id = self.worksheet.id
            
            requests = []
            
            # Column Formatting
            column_widths = {
                'A': 300,  
                'B': 200,  
                'C': 120,  
                'D': 150,  
                'E': 450,  
                'F': 450,  
                'G': 450,  
                'H': 450,  
                'I': 450,  
                'J': 450,  
                'K': 450,  
                'L': 450,  
                'M': 450,  
                'N': 450,  
                'O': 450,  
                'P': 450,  
                'Q': 450,  
                'R': 450,  
                'S': 450,  
            }
            
            for col, width in column_widths.items():
                col_index = ord(col) - ord('A')
                requests.append({
                    "updateDimensionProperties": {
                        "range": {
                            "sheetId": sheet_id,
                            "dimension": "COLUMNS",
                            "startIndex": col_index,
                            "endIndex": col_index + 1
                        },
                        "properties": {
                            "pixelSize": width
                        },
                        "fields": "pixelSize"
                    }
                })
            
            # 2. Format header rows (rows 1-2)
            header_format = {
                "backgroundColor": {"red": 0.2, "green": 0.4, "blue": 0.8},
                "textFormat": {"bold": True, "foregroundColor": {"red": 1.0, "green": 1.0, "blue": 1.0}},
                "horizontalAlignment": "CENTER",
                "verticalAlignment": "MIDDLE"
            }
            
            requests.append({
                "repeatCell": {
                    "range": {
                        "sheetId": sheet_id,
                        "startRowIndex": 0,
                        "endRowIndex": 2
                    },
                    "cell": {
                        "userEnteredFormat": header_format
                    },
                    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"
                }
            })
            
            # Alignment
            top_aligned_format = {
                "verticalAlignment": "TOP",  
                "wrapStrategy": "WRAP"
            }
            
            requests.append({
                "repeatCell": {
                    "range": {
                        "sheetId": sheet_id,
                        "startRowIndex": 2,
                        "endRowIndex": total_rows,
                        "startColumnIndex": 0,
                        "endColumnIndex": 19
                    },
                    "cell": {
                        "userEnteredFormat": top_aligned_format
                    },
                    "fields": "userEnteredFormat(verticalAlignment,wrapStrategy)"
                }
            })
            
            # 4. Background COlor
            metadata_format = {
                "backgroundColor": {"red": 0.9, "green": 0.95, "blue": 1.0},
                "textFormat": {"bold": True},
                "verticalAlignment": "TOP"
            }
            
            requests.append({
                "repeatCell": {
                    "range": {
                        "sheetId": sheet_id,
                        "startRowIndex": 2,
                        "endRowIndex": total_rows,
                        "startColumnIndex": 0,
                        "endColumnIndex": 4
                    },
                    "cell": {
                        "userEnteredFormat": metadata_format
                    },
                    "fields": "userEnteredFormat(backgroundColor,textFormat,verticalAlignment)"
                }
            })
            
            # 5. Colors
            for row in range(2, total_rows):
                if row == total_rows - 1:  
                    color = {"red": 0.9, "green": 1.0, "blue": 0.9}  # Light green
                    text_format = {"bold": True, "italic": True}
                elif row % 2 == 0:  
                    color = {"red": 1.0, "green": 0.98, "blue": 0.9}  # Light yellow
                    text_format = {}
                else:  
                    color = {"red": 0.98, "green": 0.98, "blue": 0.98}  # Light gray
                    text_format = {}
                
                requests.append({
                    "repeatCell": {
                        "range": {
                            "sheetId": sheet_id,
                            "startRowIndex": row,
                            "endRowIndex": row + 1,
                            "startColumnIndex": 4,
                            "endColumnIndex": 19
                        },
                        "cell": {
                            "userEnteredFormat": {
                                "backgroundColor": color,
                                "textFormat": text_format,
                                "verticalAlignment": "TOP",  
                                "wrapStrategy": "WRAP"
                            }
                        },
                        "fields": "userEnteredFormat(backgroundColor,textFormat,verticalAlignment,wrapStrategy)"
                    }
                })
            
            
            border_style = {
                "style": "SOLID",
                "width": 1,
                "color": {"red": 0.6, "green": 0.6, "blue": 0.6}
            }
            
            requests.append({
                "updateBorders": {
                    "range": {
                        "sheetId": sheet_id,
                        "startRowIndex": 0,
                        "endRowIndex": total_rows,
                        "startColumnIndex": 0,
                        "endColumnIndex": 19
                    },
                    "top": border_style,
                    "bottom": border_style,
                    "left": border_style,
                    "right": border_style,
                    "innerHorizontal": border_style,
                    "innerVertical": border_style
                }
            })
            
            
            requests.append({
                "updateSheetProperties": {
                    "properties": {
                        "sheetId": sheet_id,
                        "gridProperties": {
                            "frozenRowCount": 2
                        }
                    },
                    "fields": "gridProperties.frozenRowCount"
                }
            })
            
           
            for row in range(2, total_rows):
                requests.append({
                    "updateDimensionProperties": {
                        "range": {
                            "sheetId": sheet_id,
                            "dimension": "ROWS",
                            "startIndex": row,
                            "endIndex": row + 1
                        },
                        "properties": {
                            "pixelSize": 100  
                        },
                        "fields": "pixelSize"
                    }
                })
            
            # Execute all formatting requests
            if requests:
                self.spreadsheet.batch_update({"requests": requests})
                print("✅ Formatting applied successfully!")
                print("   📏 Wider columns for questions")
                print("   🔼 Text top-aligned in all cells")
                print("   🎨 Clean question-only display")
                return True
            else:
                print("⚠️  No formatting requests to apply")
                return False
            
        except Exception as e:
            print(f"⚠️  Could not apply formatting: {e}")
            return False
    
    def setup_tab_headers(self, query):
        headers = [
            'Start Question', 
            'Filtered Keyword',
            'Search Type',
            'Timestamp',
            'Result1', 'Result2', 'Result3', 'Result4', 'Result5', 'Result6', 'Result7', 'Result8',
            'Result9', 'Result10', 'Result11', 'Result12', 'Result13', 'Result14', 'Result15'
        ]
        
        main_header = [f'Start Question : {query}', f'Filtered Keyword : {query}', '', '', '']
        self.safe_append_row(main_header)
        self.safe_append_row(headers)
        print("✅ Added headers to new tab")

    def format_data_for_sheets(self, query, data, search_type):
        all_rows = []
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        if search_type == "Iterative" and 'term_specific_data' in data:
            term_specific_data = data['term_specific_data']
            searched_terms = data['iterative_search_summary']['searched_terms']
            
            for search_term in searched_terms:
                if search_term in term_specific_data:
                    rows = self.create_search_rows(search_term, term_specific_data[search_term], search_type, timestamp)
                    all_rows.extend(rows)
        else:
            rows = self.create_search_rows(query, data, search_type, timestamp)
            all_rows.extend(rows)
        
        return all_rows
    
    def create_search_rows(self, search_term, term_data, search_type, timestamp):
        rows = []
        paa_questions = term_data.get('people_also_ask', [])
        max_results_per_row = 15
        
        for i in range(0, len(paa_questions), max_results_per_row):
            batch = paa_questions[i:i + max_results_per_row]
            row_data = [
                search_term if i == 0 else '',
                search_term if i == 0 else '',
                search_type if i == 0 else '',
                timestamp if i == 0 else '',
            ]
            
            for j in range(max_results_per_row):
                if j < len(batch):
                    row_data.append(batch[j])
                else:
                    row_data.append('')
            
            rows.append(row_data)
        
        print(f"   📊 Created {len(rows)} rows for '{search_term}' with {len(paa_questions)} PAA questions (questions only)")
        return rows
    
    def add_data_to_new_tab(self, query, data, search_type):
        if not self.client:
            print("📝 Google Sheets not available - saving locally only")
            return False
            
        try:
            if not self.create_new_tab(query, search_type):
                print("⚠️  Using main sheet as fallback")
            
            self.setup_tab_headers(query)
            print("📝 Formatting data for new tab (PAA questions only)...")
            formatted_rows = self.format_data_for_sheets(query, data, search_type)
            
            rows_added = 0
            all_data_rows = []
            
            for i, row_data in enumerate(formatted_rows):
                if self.safe_append_row(row_data):
                    rows_added += 1
                    all_data_rows.append(row_data)
                    if i < 3:
                        print(f"   ✅ Added row {i+1}")
            
            self.safe_append_row([''] * 19)
            rows_added += 1
            
            summary_row = self.create_summary_row(data, search_type)
            if self.safe_append_row(summary_row):
                rows_added += 1
                all_data_rows.append(summary_row)
            
            
            total_rows = 2 + len(all_data_rows) + 1
            self.apply_formatting(total_rows)
            
            print(f"🎉 Successfully added {rows_added} rows to new tab!")
            print(f"📊 Tab contains: {len(formatted_rows)} data rows + summary")
            print(f"🎨 Clean display: Questions only, top-aligned text, wider columns")
            
            return True
            
        except Exception as e:
            print(f"❌ Failed to add data to new tab: {e}")
            return False
    
    def create_summary_row(self, data, search_type):
        total_paa = len(data.get('people_also_ask', []))
        total_pasf = len(data.get('people_also_search_for', []))
        
        if search_type == "Iterative":
            iterations = data.get('iterative_search_summary', {}).get('iterations_completed', 1)
            terms_searched = data.get('iterative_search_summary', {}).get('total_terms_searched', 1)
            summary_text = f"SUMMARY: {total_paa} PAA questions shown | {total_pasf} PASF items used for discovery only | {terms_searched} terms over {iterations} iterations"
        else:
            summary_text = f"SUMMARY: {total_paa} PAA questions shown | {total_pasf} PASF items used for discovery only"
        
        summary_row = [summary_text, '', search_type, datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
        summary_row.extend([''] * 15)
        return summary_row

def print_results(data):
    if not data:
        return
        
    print(f"\n🎉 COLLECTED DATA FOR: '{data['search_query']}'")
    print("=" * 80)
    
    if data['people_also_ask']:
        print(f"\n📋 PEOPLE ALSO ASK QUESTIONS ONLY ({len(data['people_also_ask'])} questions):")
        for i, question in enumerate(data['people_also_ask'][:10], 1):
            print(f"{i}. {question}")
    else:
        print(f"\n❌ No People Also Ask questions found")

def main():
    print("🔎 GOOGLE SCRAPER - PAA QUESTIONS ONLY")
    print("=" * 60)
    print("✨ CLEAN QUESTION DISPLAY - No answers, top-aligned text")
    print("📑 Each search creates a new tab with questions only")
    print("🎨 Clean formatting: Wider columns, text hugs top")
    print("=" * 60)
    
    sheets_manager = GoogleSheetsManager()
    sheets_ready = sheets_manager.setup_sheets()
    
    if sheets_ready:
        print("\n✅ Google Sheets integration ready!")
        print("📑 Each search will create a NEW TAB")
        print("❓ ONLY questions displayed (no answers)")
        print("🔼 Text top-aligned in all cells")
        print("📏 Wider columns for better readability")
    else:
        print("\n💡 Google Sheets not available - saving locally only")
    
    while True:
        query = input("\n📝 Enter search query: ").strip()
        if not query:
            continue
        
        print("\n🔍 Choose search type:")
        print("   1. Single search (fast)")
        print("   2. Iterative search (comprehensive)")
        search_choice = input("   Enter choice (1 or 2): ").strip()
        
        enable_iterative = search_choice == "2"
        max_iterations = 3
        
        if enable_iterative:
            try:
                iterations_input = input("   Enter number of iterations (default 3): ").strip()
                if iterations_input:
                    max_iterations = int(iterations_input)
            except ValueError:
                pass
        
        scraper = GooglePAAScraper()
        results = scraper.scrape_all_data(
            query, 
            enable_iterative_search=enable_iterative,
            max_iterations=max_iterations
        )
        
        if results:
            print_results(results)
            search_type = "iterative" if enable_iterative else "single"
            filename = f"google_data_{query.replace(' ', '_')}_{search_type}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            print(f"\n💾 Saved locally as: {filename}")
            
            if sheets_ready:
                print("\n" + "="*50)
                search_type_label = "Iterative" if enable_iterative else "Single"
                success = sheets_manager.add_data_to_new_tab(query, results, search_type_label)
                if success:
                   print("🎊 CLEAN QUESTION DATA SUCCESSFULLY ADDED TO GOOGLE SHEETS!")
                   print("🎨 Formatting: Questions only, top-aligned text, wider columns")
        
        cont = input("\n🔄 Search again? (y/n): ").strip().lower()
        if cont not in ['y', 'yes']:
            break

if __name__ == "__main__":
    main()